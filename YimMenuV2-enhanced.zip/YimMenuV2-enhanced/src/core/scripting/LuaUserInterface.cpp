#include "LuaUserInterface.hpp"

namespace YimMenu::Lua
{
	UIElementBase::UIElementBase(LuaUserInterface& interface) :
	    m_Interface(interface)
	{
	}
}