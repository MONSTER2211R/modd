#pragma once
#include <chrono>
#include <unordered_set>

namespace YimMenu
{
	class PlayerData
	{
	public:
		bool m_IsModder{};
		bool m_RunFreemodeStateKick{};
	};
}