#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Teleport : public Submenu
	{
	public:
		Teleport();
	};
}