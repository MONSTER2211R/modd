#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Vehicle : public Submenu
	{
	public:
		Vehicle();
	};
}