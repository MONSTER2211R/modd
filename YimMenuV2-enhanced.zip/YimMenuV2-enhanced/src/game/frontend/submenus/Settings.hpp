#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Settings : public Submenu
	{
	public:
		Settings();
	};
}