#pragma once
#include "core/frontend/manager/Category.hpp"

namespace YimMenu
{
	std::shared_ptr<Category> CreateOutfitsMenu();
}
