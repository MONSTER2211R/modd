#pragma once
#include "game/frontend/submenus/Recovery/HeistModifier.hpp"

namespace YimMenu::Submenus
{
	std::shared_ptr<TabItem> RenderApartmentHeistMenu();
}
