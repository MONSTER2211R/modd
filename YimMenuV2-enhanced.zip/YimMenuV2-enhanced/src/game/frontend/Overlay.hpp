#pragma once

namespace YimMenu
{
	class Overlay
	{
	public:
		static void Draw();
	};
}