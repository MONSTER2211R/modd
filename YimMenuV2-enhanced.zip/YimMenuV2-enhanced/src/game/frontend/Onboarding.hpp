#pragma once

namespace YimMenu
{
	void ProcessOnboarding();
}