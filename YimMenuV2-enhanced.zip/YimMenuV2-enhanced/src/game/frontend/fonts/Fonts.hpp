#pragma once

namespace YimMenu::Fonts
{
	extern const uint8_t MainFont[78948];
	extern const uint8_t IconFont[1049188];
}