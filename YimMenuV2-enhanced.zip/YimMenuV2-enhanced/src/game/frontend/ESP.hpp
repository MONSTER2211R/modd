#pragma once
#include "game/gta/Player.hpp"

namespace YimMenu
{
	class ESP
	{
	public:
		static void Draw();
	};
}