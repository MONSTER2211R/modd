#pragma once
#include "core/commands/HotkeySystem.hpp"

namespace YimMenu
{
	void DrawHotkey(CommandLink* link, std::string_view label);
}