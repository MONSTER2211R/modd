#pragma once
#include "lua.hpp"

namespace YimMenu::Lua
{
	void RegisterEntityMethods(lua_State* state);
}