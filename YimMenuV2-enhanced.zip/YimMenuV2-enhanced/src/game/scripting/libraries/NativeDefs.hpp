#pragma once

extern const char* g_LuaNativeDefs[];
extern int g_NumLuaNativeDefs;